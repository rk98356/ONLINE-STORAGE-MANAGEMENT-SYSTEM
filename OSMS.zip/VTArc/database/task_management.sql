-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2019 at 05:37 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `task_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `timesheet_details`
--

CREATE TABLE `timesheet_details` (
  `s_no` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mail_id` varchar(255) NOT NULL,
  `insertion_date` date NOT NULL,
  `updation_date` date NOT NULL,
  `work_assigned` varchar(255) NOT NULL,
  `work_title` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timesheet_details`
--

INSERT INTO `timesheet_details` (`s_no`, `name`, `mail_id`, `insertion_date`, `updation_date`, `work_assigned`, `work_title`, `description`) VALUES
(19, 'saif', 'saifali4785@gmail.com', '2019-09-26', '0000-00-00', 'sa', 'assahjhj', 'sa'),
(28, 'Ravi Raushan Kumar', 'ravi.vikashtech@gmail.com', '2019-09-27', '0000-00-00', 'Data entry', 'VTArc', 'Data entry');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `s_no` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `desig` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `father_name` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `percentage_cgpa` double NOT NULL,
  `college_school` varchar(255) NOT NULL,
  `university_board` varchar(255) NOT NULL,
  `aadhar` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `mobile_no` varchar(11) NOT NULL,
  `registration_date` datetime NOT NULL,
  `batch_no` int(11) NOT NULL,
  `time_slot` varchar(20) NOT NULL,
  `internship_type` tinyint(2) NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`s_no`, `user_id`, `email`, `password`, `desig`, `name`, `father_name`, `department`, `dob`, `gender`, `qualification`, `percentage_cgpa`, `college_school`, `university_board`, `aadhar`, `address`, `mobile_no`, `registration_date`, `batch_no`, `time_slot`, `internship_type`, `status`) VALUES
(1, 'TECH821', 'sanyukta217@gmail.com', '32ef3650d2d8ccd3855807a8e83cbbc7', 'Admin', 'Sanyukta', 'Santosh Kumar', '', '1994-07-21', '', 'MCA', 89, 'PWC', 'Patna University', '123456789098', 'Patna', '9472482439', '2019-07-02 07:40:00', 0, '', 0, 1),
(2, 'TECH502', 'ravi.vikashtech@gmail.com', '63dd3e154ca6d948fc380fa576343ba6', 'Intern-02', 'Ravi Raushan Kumar', '', '', '0000-00-00', '', '', 0, '', '', '', '', '', '2019-07-02 11:19:15', 0, '', 0, 1),
(3, 'TECH227', 'hussainsyedintez@gmail.com', '8aaa25aabfc6d05fca30523b1602c322', 'Intern-01', 'Syed Hussain', 'Ejaz Hussain', '', '2000-11-21', '', '12th', 98, 'P', 'Patna University', '456789097654', 'Patna', '8210126527', '2019-07-11 15:10:07', 0, '', 0, 1),
(4, 'TECH768', 'saifali4785@gmail.com', '8a9feb01e536010a2f8da9cb7d85b25f', 'Intern-01', 'saif', 'md mukhtar quraishi', '', '1999-05-13', '', 'BCA 2', 7, 'ST PAULS', 'PU', '46567895220', 'alam ganj', '9905843735', '2019-07-23 16:39:21', 0, '', 0, 1),
(5, '', 'saifqurai4785@gmail.com', '', '', 'md saif quraishi', '', '', '0000-00-00', '', '', 0, '', '', '', '', '7979856803', '0000-00-00 00:00:00', 0, '', 0, 0),
(6, '', 'saifqurai4785@gmail.com', '', '', 'md saif quraishi', '', '', '0000-00-00', '', '', 0, '', '', '', '', '7979856803', '0000-00-00 00:00:00', 0, '', 0, 0),
(7, '', 'akash.123@gmail.com', '', '', 'akash', '', '', '0000-00-00', '', '', 0, '', '', '', '', '7894561230', '0000-00-00 00:00:00', 0, '', 0, 0),
(8, '', 'akash.123@gmail.com', '', '', 'akash', '', '', '2019-09-20', '', '', 0, '', '', '', '', '7894561230', '0000-00-00 00:00:00', 0, '', 0, 0),
(9, '', 'bhaweshraj12@gmail.com', '', '', 'bhaweshraj ', '', '', '0000-00-00', '', '', 0, '', '', '', '', '1234567890', '0000-00-00 00:00:00', 0, '', 0, 0),
(10, '', 'aas@gmail.com', '', '', 'assa', '', '', '0000-00-00', '', '', 0, '', '', '', '', '7884561230', '0000-00-00 00:00:00', 0, '', 0, 0),
(11, '', 'sgf@dghd.com', '', '', 'sd', '', '', '0000-00-00', '', '', 0, '', '', '', '', '7884561230', '0000-00-00 00:00:00', 0, '', 0, 0),
(12, '', 'sgf@dghd.com', '', '', 'as', '', '', '0000-00-00', '', '', 0, '', '', '', '', '784561238', '0000-00-00 00:00:00', 0, '', 0, 0),
(13, '', 'saifali4785@gmail.com', '', '', 'md saif quraishi', '', '', '0000-00-00', '', '', 0, '', '', '', '', '7979856803', '0000-00-00 00:00:00', 0, '', 0, 0),
(14, '', 'lucky.rajarya@gmail.com', '', '', 'bhawesh raj', '', '', '0000-00-00', '', '', 0, '', '', '', '', '7561925175', '0000-00-00 00:00:00', 0, '', 0, 0),
(15, '', 'sdlk@gmail.com', '', '', 'askjk', '', '', '2019-09-19', '', '', 0, '', '', '', '', '7845612307', '0000-00-00 00:00:00', 0, '', 0, 0),
(16, '', 'saifali345@gmail.com', '', '', 'as', '', '', '1999-04-05', '', '', 0, '', '', '', '', '784561230', '0000-00-00 00:00:00', 0, '', 0, 0),
(17, 'TSM685', 'akash.123@gmail.com', '', '', 'as', '', '', '2019-09-14', '', '', 0, '', '', '', '', '7458796213', '0000-00-00 00:00:00', 0, '', 0, 0),
(18, 'TSM935', 'sdfbnm@gmail.com', '', '', 'jhsahjhj', '', '', '2019-09-13', '', '', 0, '', '', '', '', '4556122301', '0000-00-00 00:00:00', 0, '', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `timesheet_details`
--
ALTER TABLE `timesheet_details`
  ADD PRIMARY KEY (`s_no`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`s_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `timesheet_details`
--
ALTER TABLE `timesheet_details`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `s_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
