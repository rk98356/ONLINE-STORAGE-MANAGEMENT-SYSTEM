<div class="d-flex" id="wrapper">

    <!-- Sidebar -->
    <div class="border-right" id="sidebar-wrapper">

        <div class="list-group list-group-flush">
            <a href="vtr_index_view.php" class="list-group-item list-group-item-action " style="background: #fff; color:rgb(0,0,51);"><?php echo $_SESSION['desig']; ?> Dashboard</a>
<?php
if($_SESSION['desig']=="Intern-01" || $_SESSION['desig']=="Intern-02"){
     echo'<ul style="list-style-type: none; margin-top:15px; margin-bottom: 5px; margin-left: 0px;">
                <li class="side-item dropdown">      
                  <a href="#" class="side-link dropdown-toggle"  id="navbarDropdown"  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="text-decoration:none; color:rgb(0,0,51);"> 
                    <i class="fa fa-file" aria-hidden="true"></i>&nbsp; Timesheet
                  </a>
                  <div class="dropdown-menu dropdown-menu-right" aria-labelledby="sidebarDropdown" >
                      <a class="dropdown-item" href="tsm_add.php">
                          <i class="fa fa-plus" aria-hidden="true"></i> &nbsp;Add Timesheet
                        </a>
                      <a class="dropdown-item" href="tsm_edit.php">
                          <i class="fa fa-edit" aria-hidden="true"></i> &nbsp;Edit Timesheet
                        </a>
                      <a class="dropdown-item" href="tsm_view.php">
                          <i class="fa fa-eye" aria-hidden="true"></i> &nbsp;View Timesheet
                        </a>

                  </div>
                </li>
            </ul>';
        }
else if($_SESSION['desig']=="Admin"){
     echo'<ul style="list-style-type: none; margin-top:15px; margin-bottom: 5px; margin-left: 0px;">
                <li class="side-item dropdown">

                    <a class="side-link dropdown-toggle" style="text-decoration-line:none; color: rgb(0,0,51);" href="#"  id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" >
                        <i class="fa fa-user" aria-hidden="true"></i>&nbsp; user
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="sidebarDropdown">
                        <a class="dropdown-item" href="ad_add_user.php">
                            <i class="fa fa-plus" aria-hidden="true"></i> &nbsp; Add User</a>
                        <a class="dropdown-item" href="ad_view_user.php">
                            <i class="fa fa-eye" aria-hidden="true"></i> &nbsp;View User</a>
                        <a class="dropdown-item" href="ad_edit_user.php">
                            <i class="fa fa-edit" aria-hidden="true"></i>&nbsp; Edit User </a>
                        <a class="dropdown-item" href="tsm_current.php">
                         <hr/>
                          <i class="fa fa-eye" aria-hidden="true"></i> &nbsp;View current timesheet</a>
                        <a class="dropdown-item" href="tsm_view_all.php">
                          <i class="fa fa-eye" aria-hidden="true"></i> &nbsp;View all
                        </a>
                    </div>
                </li>
            </ul>
            
                </li>
            </ul>';
      }
?>
      
               <ul style="list-style-type: none; margin-top:15px; margin-bottom: 5px; margin-left: 0px;">
                
            </ul>
        </div>
    </div>