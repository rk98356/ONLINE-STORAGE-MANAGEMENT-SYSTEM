function validation()
     {
        //alert(1);
       // var addtimesheet_name = $('#addtimesheet_name').val();
        var work_assigned = $('#work_assigned').val();
        var work_title = $('#work_title').val();
        var description = $('#description').val();
        //alert()
       // if(addtimesheet_name == null || addtimesheet_name == ""); 
        //{
            //alert(1);
        //$("#name_check").html('**Please fill the name');
        //return false;
        //}
       	if(work_assigned == null || work_assigned == "")
        {
    		//alert(1);
    		$('#work_assigned_check').html('**please fill the assigned');
    		//return false;
        }
        if(work_title== null || work_title == "")
        {
    		//alert(1);
    		$('#work_title_check').html('**please fill the title');
    		//return false;
    	}
        if(description == null || description == "")
        {
    		//alert(1);
    		$('#description_check').html('**please fill the description ');
    		//return false;
    	}
    }
    		
    			$(document).on('click','#add_timesheet',function(){
    		   validation();
    		});

    //validation on page edit timesheet
   /* function validation2()
     {
        //alert(1);
       // var addtimesheet_name = $('#addtimesheet_name').val();
        var work_assigned =$('#work_assigned').val();
        var work_title =$('#work_title').val();
        var description=$('#description').val();
        //alert()
       // if(addtimesheet_name == null || addtimesheet_name == ""); 
        //{
            //alert(1);
        //$("#name_check").html('**Please fill the name');
        //return false;
        //}
       	if(work_assigned == null || work_assigned == "")
        {
    		//alert(1);
    		$("#assigned_check").html("**please fill the assigned ");
    		//return false;
        }
        if(work_title== null || work_title == "")
        {
    		//alert(1);
    		$("#title_check").html("**please fill the title ");
    		//return false;
    	}
        if(description == null || description == "")
        {
    		//alert(1);
    		$("#description_check").html('**please fill the description ');
    		//return false;
    	}
    }
    		
    			$(document).on('click','#save1',function(){
    		   validation2();
    		});*/





       // document.getElementById('title_check').innerHTML="**Please Fill The Work title";
       // document.getElementById('description_check').innerHTML="**Please Fill The description";
       // return false;
       // }