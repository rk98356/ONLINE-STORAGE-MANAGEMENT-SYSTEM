<div class="container" style="margin-top: 2%;  background: #fff; color:rgb(0,0,51);">
    <div class="row jumbotron">

        <div class="col-md-2">
            <img src="ad_picture.png" style="height:80px; border-radius: 600px; border:1px solid rgb(0,0,51);">
        </div>

        <div class="col-md-2">
            <label><b>Name:</b></label>
            <label>Saurabh kumar</label>
            <label><b>Registration Date:</b></label>
            <label>13/06/19</label>
        </div>
        <div class="col-md-2">
            <label><b>User Id:</b></label>
            <label>123456</label>
            <label><b>Ref.No:</b></label>
            <label>684032</label>
        </div>
        <div class="col-md-2">
            <label><b>Email:</b></label>
            <label>thepostmaster7@gmail.com</label>
        </div>
        <div class="col-md-2"></div>
        <div class="col-md-2">
            <label><b>Moblie.No:</b></label>
            <label>+918210652266</label>
        </div>

    </div>
    <div class="row" style="margin-top: 10px;">
        <div class="col-md-1"></div>
        <div class="col-md-5 card">
            <h3 class="card-header">Personal Detail...</h3>
            <p class="list-group list-group-item">
                <label><b>Father Name:</b></label>
                <label>Uday Kumar Singh</label>
            </p>

            <p class="list-group list-group-item">
                <label><b>DOB:</b></label>
                <label>03/12/1996</label>

                <p class="list-group list-group-item">
                    <label><b>Address:</b></label>
                    <label>Goshala Road, Sonaili, Katihar dis:katihar, pot:sonaili Goshala Road, Sonaili, Katihar
                    </label>
                    <p class="list-group list-group-item">
                        <label><b>Aadhar.No:</b></label>
                        <label>12345678925671</label>
        </div>
        <div class="col-md-1"></div>
        <div class="col-md-4 card">
            <h3 class="card-header">Educational Detail...</h3>
            <p class="list-group list-group-item">
                <label><b>Highest Qualification:</b></label>
                <label>Graduate</label>
            </p>
            <br/>
            <p class="list-group list-group-item">
                <label><b>CGPA/Percent:</b></label>
                <label>75%</label>
            </p>
            <br/>
            <p class="list-group list-group-item">
                <label><b>School/College:</b></label>
                <label>CIMAGE College, boring riad, Patna</label>
                <br/>
            </p>
            <p class="list-group list-group-item">
                <label><b>University/Board:</b></label>
                <label>Magadh University</label>
            </p>

        </div>

        <div class="col-md-1"></div>
    </div>
</div>