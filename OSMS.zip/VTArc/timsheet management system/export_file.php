<?php
$filename =$_GET['filename'];
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename='.$filename.'.xls');  
session_start();
echo "<html>";
echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=Windows-1252\">";
echo "<body>";
echo $_SESSION['contents'];
echo "</body>";
echo "</html>";
?>