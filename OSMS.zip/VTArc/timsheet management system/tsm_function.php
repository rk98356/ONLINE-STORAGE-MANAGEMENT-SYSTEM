 <?php

    date_default_timezone_set('Asia/Kolkata');
    if(isset($_POST['timesheet']) && $_POST['timesheet']=='check')
    {
        session_start();
        $con = mysqli_connect('localhost','root','','task_management');
        $work_title = mysqli_real_escape_string($con, $_POST['work_title_key']);
        $work_assigned = mysqli_real_escape_string($con, $_POST['work_assigned_key']);
        $description = mysqli_real_escape_string($con, $_POST['description_key']); 
        $idate = date("Y-m-d");
        //$udate = date("Y-m-d");
        $mail = $_SESSION['username'];

        $query = "INSERT INTO `timesheet_details`(`name`,`insertion_date`,`work_assigned`,`work_title`,`description`,`mail_id`) VALUES ('".$_SESSION['name']."' , '".$idate."', '".$work_assigned."', '".$work_title."', '".$description."','".$mail."')"; 
        $result =  mysqli_query($con,$query);
        //echo $query;
        

    }

    if(isset($_POST['timesheet']) && $_POST['timesheet']=='update')
    {
        session_start();
        $con = mysqli_connect('localhost','root','','task_management');
        
        $update_work_title = mysqli_real_escape_string($con, $_POST['work_title_key']);
        $update_work_assigned = mysqli_real_escape_string($con, $_POST['work_assigned_key']);
        $update_description = mysqli_real_escape_string($con, $_POST['description_key']); 
        $s_no = mysqli_real_escape_string($con, $_POST['s_no']); 
       // $date = date("Y-m-d H:i:s");
       // $udate = date("Y-m-d H:i:s");
       // $user_id = "TSM".rand(100,999);
        $mail = $_SESSION['username'];

        $query = "UPDATE `timesheet_details` SET `work_assigned`='".$update_work_assigned."',`work_title`='".$update_work_title."',`description`='".$update_description."' WHERE `s_no`= '".$s_no."'";
     
        $result =  mysqli_query($con, $query);
        echo $query;
            //echo "12345";/
    }

if(isset($_POST['viewall']) && $_POST['viewall']=='check')
    {
        session_start();
        $con = mysqli_connect('localhost','root','','task_management');
        $name1 = mysqli_real_escape_string($con, $_POST['name1_key']);
        $start_date_key = mysqli_real_escape_string($con, $_POST['start_date_key']);
        $end_date_key = mysqli_real_escape_string($con, $_POST['end_date_key']);
        //$end_date = mysqli_real_escape_string($con, $_POST['end_date']); 
        //$udate = date("Y-m-d");

        $query = "SELECT * FROM `timesheet_details` WHERE `insertion_date` between '".$start_date_key."' AND '".$end_date_key."' AND `name`='".$name1."' ";
        $result =  mysqli_query($con,$query);
        $s_no=1;
        while ($row =  mysqli_fetch_array($result)) {
            # code...
        
  echo '<table class="table table-bordered dataTable" cellspacing="0" cellpadding="0"  width="100%">
            <thead>
                <tr>
                  <th>S.no</th>
                  <th>Name</th>
                  <th>Date</th> 
                  <th>Work assigned</th>
                  <th>Title</th>
                  <th>Description</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                  <td align="center">'.$s_no.'</td>
                  <td align="center">'.$row["name"].'</td>
                  <td align="center">'.$row["insertion_date"].'</td>
                  <td align="center">'.$row["work_title"].'</td>
                  <td align="center">'.$row["description"].'</td>
                  <td align="center">'.$row["work_assigned"].'</td>
                </tr>
            </tbody>
          </table>';
          $s_no++;
        }

    }
        



?>