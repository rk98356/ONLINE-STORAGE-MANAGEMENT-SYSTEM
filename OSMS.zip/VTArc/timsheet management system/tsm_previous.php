<?php include('vtr_header.php');?>
<?php include('vtr_top_menu.php');?>
<?php include('vtr_side_nav.php');?>

 <div class="container-fluid" style="margin-top: 4%; height: 60vh;">
  <div class="row">
    <div class="col-md-1"></div>
    <div class="col-md-10" style="background: #fff; color:rgb(0,0,51); min-height:70vh; padding-top:10px;" >
      <div class="row" style="border-bottom: 2px solid rgb(0,0,51);">
          <div class="col-md-7"><i class="fa fa-eye" aria-hidden="true"></i> &nbsp;<b>Previous Timesheet</b></div>
              
            <div class="col-md-2">
              <label><?php echo date('d-m-Y');?></label>
            </div>
            <div class="col-md-3">
              <div id="time-cont"></div>
                <!-- <label><?php echo date('H:i:s a');?></label>  -->  
            </div>    
      </div><br/>
      <div class="row">
        <div class="col-md-12 table-responsive" style="background:#fff;">
          <div class="row">
          <div class="input-group col-sm-6">  
            <select class="form-control " style="width:20%;">
              <option>Select Month</option>
              <option>January</option>
              <option>Febuary</option>
              <option>March</option>
              <option>April</option>
              <option>May</option>
              <option>June</option>
              <option>July</option>
              <option>August</option>
              <option>September</option>
              <option>October</option>
              <option>November</option>
              <option>December</option>
            </select>
                <button class="btn btn-info" type="button">Go!</button>
          </div>
          <div class="col-sm-6">
          </div>
        </div>
        <br/>
          <table class="table table-bordered dataTable" cellspacing="0" cellpadding="0"  width="100%">
            <thead>
            <tr>
              <th>S.no</th>
              <th>Date</th> 
              <th>Work assigned</th>
              <th>Title</th>
              <th>Description</th>
            </tr>
            </thead>
            <tbody>
<?php
      $query ="SELECT * FROM `worksheet` WHERE `user_id` = '".$_SESSION['username']."'  ORDER BY `date_of_insertion` desc ";
      $con = mysqli_connect('localhost','root','','task_management');
      $result =  mysqli_query($con,$query);
      $s_no=1;
      while ($row = mysqli_fetch_array($result)) {
       echo'<tr>
              <td align="center">'.$s_no.'</td>
              <td>'.$row["date_of_insertion"].'</td>
              <td>'.$row["user_id"].'</td>
              <td align="center">'.$row["title"].'</td>
              <td>'.$row["description"].'</td>
            </tr>'  ;
            $s_no++;
      }     
?>
            </tbody>
          </table>
        </div>
      </div><br/>

    </div>
    <div class="col-md-1"></div>
  </div>
 </div>
 <?php include('vtr_footer.php');?> 