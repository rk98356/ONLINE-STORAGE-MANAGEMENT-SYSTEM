var flag = 0;
var swal;

function varifynull(vari, message) {
    if (vari === null || vari === "" || vari === 'undefined') {
        alert(message);
        flag++;
    }
}

function validateemail(email) {
    var atposition = email.indexOf("@");
    var dotposition = email.lastIndexOf(".");
    if (atposition < 1 || dotposition < atposition + 2 || dotposition + 2 >= email.length) {
        alert("Please enter a valid e-mail address");
        flag++;
    }
}
/*function validatedate(dob,message)
{
	var dateformat = /^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$/;
	    if(!dob.match(dateformat)){
	    	alert(message);
	    	flag++;
	    }
}*/
$(document).on('blur focusout', '#email', function() {
    //alert("hello");
    var email = $('#email').val();
    $.ajax({
        method: 'post',
        url: 'ad_register.php',
        data: {
            email: email,
            required: 'emailValidation'
        },
        beforeSend: function(){
            $("#blank").css("display","block");
        },
        complete: function(){
            $("#blank").css("display","none");
        },
        success: function(data) {
            //alert(data);
            if (data == "already") {
                swal("ohhh no", "Email Already exists", "error");
                $("#email").val("");
            } else if (data == "true") {
                //nothingf
            }
            //alert(data);

        }
    });
});
$(document).on('click', '#submit', function() {
    var name = $('#name').val();
    varifynull(name, "Name must be filled!");
    var email = $('#email').val();
    validateemail(email);
    var mobileno = $('#mobileno').val();
    varifynull(mobileno, "Mobile no. must be filled!");
    var dob = $('#dob').val();
    varifynull(dob, "DOB must be filled!");
    var desig = $('#desig').val();
    varifynull(desig, "Designation must be filled!");
    var department = $('#department').val();
    varifynull(department, "Department must be filled!");
    var gender = $('#gender').val();
     varifynull(gender, "Gender must be filled!");
   
    if (flag == 0) {
        $.ajax({
            method: 'post',
            url: 'ad_register.php',
            data: {
                submit: 'submit',
                namekey: name,
                emailkey: email,
                mobilenokey: mobileno,
                desigkey:desig,
                dobkey:dob,
                departkey:depart,
                genderkey:gender
                
                
            },
            beforeSend: function(){
            $("#blank").css("display","block");
            },
            complete: function(){
            $("#blank").css("display","none");
            },
            success: function(data) {
                swal({
                        text: data,
                        type: 'success',
                        title: 'Well Done',
                        button: {
                            text: "OK!",
                            closeModal: false

                        }
                    })
                    .then(willSearch => {
                        if (willSearch) {
                            window.location.href = "ad_add_user.php";
                        }
                    })
            }
        });
    } else {
        alert(data);
    }
});

/*$(document).on('submit','#update_user_details', function(e) {
    e.preventDefault();
    var sno = $('#update_sno').val();

    var mobileno = $('#update_mobileno').val();
    varifynull(mobileno, "Mobile no. must be filled!");
        if (flag === 0) {
            alert("e");
        $.ajax({
            method: 'post',
            url: 'ad_register.php',
            data: {
                submit: 'update',
                snokey: sno,
                mobilenokey: mobileno,
            },
            beforeSend: function(){
            $("#blank").css("display","block");
            },
            complete: function(){
            $("#blank").css("display","none");
            },
            success: function(data) {
                swal({
                        text: data,
                        type: 'success',
                        title: 'Well Done',
                        button: {
                            text: "OK!",
                            closeModal: false,
                        },
                    })
                    .then(willSearch => {
                        if (willSearch) {
                            window.location.href = "ad_edit_user.php";
                        }
                    })
            }
        });
    } else {
        alert(data);
    }
});*/ 