 
function varifynull(vari,message)
{
	if(vari===null || vari==="" || vari==='indefined')
	{ 
	  flag++;  
	  return false; 
	}
}

$(document).on('click','#add_timesheet',function(e){
	e.preventDefault();
	var work_title = $('#work_title').val();
	varifynull(work_title,"Work Title must be filled!");
	var work_assigned = $('#work_assigned').val();
	varifynull(work_assigned,"Work Assigned must be filled!");
	var description = $('#description').val();
	varifynull(description,"Description must be filled!");
	
  if(flag===0)
{	
	$.ajax({
		method:'post',
		url:'tsm_function.php',
		data:{
			timesheet:'check',
			work_title_key:work_title,
			work_assigned_key:work_assigned,
			description_key:description
		},
		beforeSend: function(){
    		$("#blank").css("display","block");
   		},
  		complete: function(){
  		    $("#blank").css("display","none");
 		},
		success:function(data){
			if(data){
			swal({
				  text:data,
				  type: 'success',
				  title: 'Well Done'
				})
				.then(willSearch => {
				  if (willSearch) {
				    window.location.href="tsm_view.php";
				  }
				})
				}
			else{
				alert(data);
			}
		}
	});
}
});


$(document).on('click','#updatework',function(){
	//e.preventDefault();
	var work_title = $('#update_work_title').val();
	//alert(work_title);
	//varifynull(work_title,"Work Title must be filled!");
	var work_assigned = $('#update_work_assigned').val();
	//varifynull(work_assigned,"Work Assigned must be filled!");
	var description = $('#update_description').val();
	//varifynull(description,"Description must be filled!");
	var s_no = $('#s_no').val();

	
	$.ajax({
		method:'post',
		url:'tsm_function.php',
		data:{
			timesheet:'update',
			work_title_key:work_title,
			work_assigned_key:work_assigned,
			description_key:description,
			s_no:s_no
		},
		success:function(data){
			swal({
				  text: data,
				  type: 'success',
				  title: 'Well Done',
				  button: {
				    text: "OK!",
				    closeModal: false,
				  },
				})
				.then(willSearch => {
				  if (willSearch) {
				    window.location.href="tsm_view.php";
				  }
				})
		}
	});

});


$(document).on('click','#search',function(e){
	e.preventDefault();
	
	var name1 = $('#name1').val();
	var start_date = $('#start_date').val();
	var end_date = $('#end_date').val();
	//alert(name1);
	//alert(start_date);
	//alert(end_date);
	

	$.ajax({
		method:'post',
		url:'tsm_function.php',
		data:{
			viewall:'check',
			name1_key:name1,
			start_date_key:start_date,
			end_date_key:end_date
		},
		beforeSend: function(){
    		$("#blank").css("display","block");
   		},
  		complete: function(){
  		    $("#blank").css("display","none");
 		},
		success:function(data){
			if(data){
				$('#viewall').html(data);
				}
			else{
				alert(data);
			}
		}
	});
});