<div class="container-fluid">
    <div class="row" style="margin-top: 5%; min-height: 70vh;">
        <div class="col-md-2"></div>
        <form class="col-sm-8" style="background:white; min-height:400px; border:2px solid green; border-radius:0px 10px 10px 0">
            <div id='a'>
                <h5>Basic Detail</h5>
                <br/>
                <label style="margin-top:10px; margin-bottom:0px;">Name</label>
                <br/>

                <input type="text" placeholder=" nidhi" class="form-control" required="true" id="name">
                <br/>
                <label style="margin-top:10px; margin-bottom:0px;">Mobile-no</label>
                <br/>
                <input type="number" placeholder=" 34567890 " class="form-control" required="true" id="mobileno">
                <br/>

                <label style="margin-top:10px; margin-bottom:0px;">Email</label>
                <br/>
                <input type="email" placeholder=" thepostmaster7@gmail.com" class="form-control" required="true" id="email">
                <br/>
                <br/>

                <button class="btn " style="background:rgb(0, 0, 51); color:#fff;" id="pageOneNextButton">Next</button>
                <br/>
                <br/>
            </div>

            <div id='b'>
                <h5> Personal Detail </h5>
                <br/>
                <label style="margin-top:10px; margin-bottom:0px;">Father Name</label>
                <br/>

                <input type="text" placeholder="erjgjgife" class="form-control" required="true" id="fname">
                <br/>
                <label style="margin-top:10px; margin-bottom:0px;">DOB</label>
                <br/>
                <input type="date" placeholder="03/12/1996" class="form-control" required="true" id="dob">
                <br/>

                <label style="margin-top:10px; margin-bottom:0px;">Aadhar Number</label>
                <br/>
                <input type="number" placeholder="245678909876" class="form-control" required="true" id="aadhar" />
                <br/>

                <label style="margin-top:10px; margin-bottom:0px;">Address</label>
                <br/>
                <input type="text" placeholder="ertytwrthggrerjhngtgfhehrfu" class="form-control" required="true" id="address" />
                <br/>
                <div>
                    <button class="btn btn-primary" style="background:rgb(0, 0, 51); color:#fff;" id="TwoNext2Button">Previous</button>
                    <button class="btn btn-primary" id="TwoNext1Button" style="background:rgb(0, 0, 51); color:#fff;">Next</button>
                    <br/>
                    <br/>
                </div>
            </div>
            <div id='c'>
                <h5>Educational Details</h5>
                <br/>
                <label style="margin-top:10px; margin-bottom:0px;">Highest Qualification </label>
                <br/>
                <input type="text" placeholder="Graduate" class="form-control" required="true" id="qua">
                <br/>
                <label style="margin-top:10px; margin-bottom:0px;">Percent/CGPA</label>
                <br/>
                <input type="number" placeholder="64%" class="form-control" required="true" id="cgpa">
                <br/>
                <label style="margin-top:10px; margin-bottom:0px;">School/College</label>
                <br/>
                <input type="text" placeholder="Cimage college" class="form-control" required="true" id="sch">
                <br/>
                <label style="margin-top:10px; margin-bottom:0px;">University/Board</label>
                <br/>
                <input type="text" placeholder="Magadh University" class="form-control" required="true" id="board">
                <br/>
                <div>
                    <button class="btn btn-primary" id="btn3" style="background:rgb(0, 0, 51); color:#fff;">Previous</button>
                    <button class="btn" style="background:rgb(0, 0,51); color:#fff;" id="Next">Next</button>
                </div>
                <br/>
            </div>

            <div id='d'>
                <p id="loerm">Lorem ipsum was popularized in the 1960s with Letraset's dry-transfer sheets, and later entered the digital world via Aldus PageMaker. Lorem ipsum was popularized in the 1960s with Letraset's dry-transfer sheets, and later entered the digital world via Aldus PageMaker.</p>
                <br/>

                <label style="margin-top:10px; margin-bottom:0px;">Intership type</label>
                <br/>
                <select class="form-control">
                    <option>Type 1</option>
                    <option>Type 2</option>
                </select>
                <br/>

                <input type="file" name="myfile" required="true" id="file">
                <br/>
                <br/>
                <p>
                    <input type="checkbox"><a href="#">&nbsp;I agree terms and condition</a></p>
                <br/>

                <p>
                    <button class="btn btn-primary" id="btn4" style="background:rgb(0, 0, 51); color:#fff;">Previous</button>
                    <input type="submit" class="btn" style="background: rgb(0, 77, 0); color:#fff;" value="submit">
                </p>
            </div>
        </form>
        <div class="col-md-2"></div>
    </div>
</div>