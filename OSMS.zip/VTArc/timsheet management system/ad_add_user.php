<?php include('vtr_header.php');?>
<?php include('vtr_top_menu.php');?>
<?php include('vtr_side_nav.php');?>
<?php if($_SESSION['desig']=="Intern"){
    echo "<script>window.location.href='vtr_index_view.php';</script>";
} ?>
            <div class="container-fluid" style="overflow-y:scroll;">
                <form class="row" method="POST" id="register_form" style="margin-top: 5%; height: 50vh;">
                    <div class="col-md-2"></div>
                    <div class="col-sm-8" style="background:white; min-height: 470px; border:2px solid green; border-radius:0px 10px 10px 0;">
                        <div id='a'>
                            <h5> Basic Detail</h5>
                            <br/>
                            <br/>
                            <div class="row">
                                <div class="col-md-6">
                                    <label style="margin-top:10px; margin-bottom:0px;"><b>Name:</b></label>
                                    <br/>
                                    <input type="text" placeholder=" Enter Your Name.." class=" form-control" required="true" id="name">
                                </div>
                                
                                <div class="col-md-6">
                                    <label style="margin-top:10px; margin-bottom:0px;"><b>Mobile-no:</b></label>
                                    <br/>
                                    <input type="number" placeholder="  Your Mobile-no.." class="form-control" required="true" id="mobileno">
                                </div>
                                
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <label style="margin-top:10px; margin-bottom:0px;"><b>Email:</b></label>
                                <br/>
                                <input type="email" placeholder=" Enter Your Email.." class="form-control" required="true" id="email">
                                
                                </div>
                                <div class="col-md-6">
                                    <label style="margin-top:10px; margin-bottom:0px;"><b>Designation</b></label>
                                    <br/>
                                    <select class="form-control" id="desig" required="true">
                                    <option value="">--Select--</option>
                                    <option value="Software Trainee">Software Trainee</option>
                                    <option value="Software Engineer">Software Engineer</option>
                                    <option value="Senior Software Engineer">Senior Software Engineer</option>
                                    <option value="Team Lead">Team Lead</option>
                                    <option value="Project Lead">Project Lead</option>
                                    <option value="Asst Project Manager">Asst Project Manager</option>
                                    <option value="Project Manager">Project Manager</option>
                                    <option value="Snr Project Manager">Snr Project Manager </option>
                                    <option value="Project - Delivery Head"> Project - Delivery Head</option>
                                    <option value="Business Head"> Business Head </option>
                                    <option value="Senior Consulant">Senior Consulant</option>
                                    <option value="Principal Consultant">Principal Consultant</option>
                                    <option value="Head of Practice">Head of Practice</option>
                                    <option value="In to IT Consulting (Process / IT / Security Consultants) Consultant">In to IT Consulting (Process / IT / Security Consultants) Consultant</option>
                                    </select>
                                    
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label style="margin-top:10px; margin-bottom:0px;"><b>DOB:</b></label>
                                        <br/>
                                        <input type="date" placeholder="date of birth.." class="form-control" required="true" id="dob">
                                        
                                    </div>
                                    <div class="col-md-6">
                                        <label style="margin-top:10px; margin-bottom:0px;"><b>Department:</b></label>
                                        <br/>
                                        <input type="text" placeholder="department.." class="form-control" required="true" id="department">
                                        
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label style="margin-top:10px; margin-bottom:0px;"><b>Gender:<b></label>
                                        <br/>
                                        <select class="form-control" id="gender" required="true">
                                        <option value="">--GENDER--</option>
                                        <option value="Male">Male</option>
                                        <option value="Female">Female</option>
                                        <option value="Can't Say">Other</option>
                                        </select>
                                        
                                    </div>
                                    <div class="col-md-6"></div>
                                </div>

                            <input type="submit" class="btn btn-success"  style="margin:15px 0px 80px 300px;" id="submit" value="Submit">
                        </div>
                    <div class="col-md-2"></div>
                </form>
            </div>
            <?php include('vtr_footer.php');?>