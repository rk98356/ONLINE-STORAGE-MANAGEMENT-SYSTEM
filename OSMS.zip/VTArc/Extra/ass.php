<html>
	<body>
		<div style=" height: 60px;overflow: scroll;">
			<table style="width: 100%" >
            <tr>
              <th>S.no</th>
              <th>Name</th> 
              <th>Date of Registration</th>
              <th>User Id</th>
               <th>Mobile.no</th>
                <th>Email</th>
                 <th><a href="#" data-toggle="modal" data-target="#more" style="color:#fff;">More</a></th>
            </tr>
            <tr>
              <td>1</td>
              <td>Today</td>
              <td>Task management System</td>
              <td><p>Lorem ipsum is .</p></td>
              <td> print, and publishing  </td>
              <td>the graphic,layouts </td>
              <td><a href="#" data-toggle="modal" data-target="#more" style="color:rgb(0,0,51);">View Details</a>  </td>
            </tr>

            <tr>
              <td>1</td>
              <td>Today</td>
              <td>Task management System</td>
              <td><p>Lorem ipsum is placeholder text commonly used </p></td>
              <td> print, and publishing industries for previewing </td>
              <td>the graphic,layouts and visual mockups</td>
              <td><a href="#" data-toggle="modal" data-target="#more" style="color:rgb(0,0,51);">View Details</a></td>
            </tr>
            <tr>
              <td>1</td>
              <td>Today</td>
              <td>Task management System</td>
              <td><p>Lorem ipsum is placeholder text commonly used in</p></td>
              <td> print, and publishing  </td>
              <td>the graphic,layouts </td>
              <td><a href="#" data-toggle="modal" data-target="#more" style="color:rgb(0,0,51);">View Details</a> </td>

            </tr>
            
          </table>
           <table style="width: 100%" >
            <label>Yesterday</label>
            <tr>
              <th>S.no</th>
              <th>Date</th> 
              <th>Name</th>
              <th>Title</th>
               <th>Description</th>
                 <th>Edit</th>
            </tr>
            <tr>
              <td>1</td>
              <td>13/06/19</td>
              <td>Nidhi</td>
              <td>Task Management</td>
                  <td><p>Lorem ipsum is .
                   print, and publishing 
                  the graphic,layouts 
                 the graphic,layouts  s</p></td>
                 <td>Edit</td>
            </tr>

            <tr>
               <td>2</td>
              <td>14/06/19</td>
              <td>Nidhi</td>
              <td>Task Management</td>
                  <td><p>Lorem ipsum is .
                   print, and publishing 
                  the graphic,layouts 
                 the graphic,layouts  s</p></td>
                 <td>Edit</td>
            </tr>
            <tr>
               <td>3</td>
              <td>15/06/19</td>
              <td>Nidhi</td>
              <td>Task Management</td>
                  <td><p>Lorem ipsum is .
                   print, and publishing 
                  the graphic,layouts 
                 the graphic,layouts  s</p></td>
                 <td>Edit</td>

            </tr>
            
          </table>
          <table style="width: 100%" >
            <label>12/06/19</label>
            <tr>
              <th>S.no</th>
              <th>Date</th> 
              <th>Name</th>
              <th>Title</th>
               <th>Description</th>
                 <th>Edit</th>
            </tr>
            <tr>
              <td>1</td>
              <td>13/06/19</td>
              <td>Nidhi</td>
              <td>Task Management</td>
                  <td><p>Lorem ipsum is .
                   print, and publishing 
                  the graphic,layouts 
                 the graphic,layouts  s</p></td>
                 <td>Edit</td>
            </tr>

            <tr>
               <td>2</td>
              <td>14/06/19</td>
              <td>Nidhi</td>
              <td>Task Management</td>
                  <td><p>Lorem ipsum is .
                   print, and publishing 
                  the graphic,layouts 
                 the graphic,layouts  s</p></td>
                 <td>Edit</td>
            </tr>
            <tr>
               <td>3</td>
              <td>15/06/19</td>
              <td>Nidhi</td>
              <td>Task Management</td>
                  <td><p>Lorem ipsum is .
                   print, and publishing 
                  the graphic,layouts 
                 the graphic,layouts  s</p></td>
                 <td>Edit</td>

            </tr>
            
          </table>
		</div>
	</body>

</html>
